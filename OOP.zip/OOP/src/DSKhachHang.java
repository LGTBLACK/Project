import java.rmi.Remote;
import java.util.Scanner;

public class DSKhachHang {
    private KhachHang kh[] = new KhachHang[100];
    private int ktkh, sum1=0, sum2=0,dem=0, sumtien=0, dem1=0, dem2=0;
    Scanner sc = new Scanner(System.in);


    public DSKhachHang(){
        ktkh=0;
        for (int i=0; i<100; i++)
        {
            kh[i] = new KhachHang();
        }
    }
    public void ThemKH ( int temp){
        if(ktkh >100){
            System.out.println("bo nho day");
        } else {
            if (temp == 1){
                kh[ktkh] = new KhachHangVN();
                KhachHangVN khv = new KhachHangVN();
                khv.nhap();
                khv.thanhtien = khv.ttien();
                kh[ktkh] = khv;
                sum1+= khv.solg;
                dem1++;
                        } else {
                            kh[ktkh] = new KhachHangNN();
                            KhachHangNN khnn = new KhachHangNN();
                            khnn.nhap();
                            khnn.thanhtien = khnn.ttien();
                            kh[ktkh] = khnn;
                            sum2+=khnn.solg;
                            sumtien+=khnn.thanhtien;
                            dem2++;
                        }
                        dem++;
                        ktkh++;
        }
    }
        public void xoaKH(int g) {
            g = sc.nextInt();
            for (int i=0; i<ktkh; i++)
            {
              i=g;
              kh[i]=kh[i+1];  
            }
            ktkh--;
        }
        public void HienThi()
        {
            for ( int i =0; i<ktkh; i++)
            {
                System.out.println("So tt" +(i+1));
                System.out.println(kh[i].toString());
            }
        }
        public void TOngSL()
        {
            System.out.println("tong so luong (kw) cua khang vit nam" + sum1);
            System.out.println("tong so long (kw) cua khach nuoc ngoai" + sum2);
        }
        public void trungbinh()
        {
            System.out.printf("trung binh thanh tien cua khach nuoc ngoai: ", + (sumtien/dem));
        }
        public void TimKH(int g){
            g = sc.nextInt();
            for (int i=0; i<ktkh; i++)
            {
              i=g;
              kh[i]=kh[i+1]; 
              System.out.println("So tt" +(i+1));
              System.out.println(kh[i].toString());
            }
        }
        public void Slkh(){
              System.out.println("so khach hang viet nam la:  " + dem1);
                System.out.println("so khach hang nuoc ngoai la:  "+ dem2);
            }
            public void ThangHD(int g){
                g = sc.nextInt();
                for (int i=0; i< ktkh; i++)
                {
                  if (g == kh[i].getThangHD())
                  kh[i]=kh[i+1]; 
                  System.out.println("So tt" +(i+1));
                  System.out.println(kh[i].toString());
                }
            }    
        
        }
        