public class KhachHangVN extends KhachHang {
    private int LoaiKH;
    private int dinhmuc;

    public KhachHangVN(){
        super();
        this.LoaiKH = 0;
        this.dinhmuc = 0;
        

    }
    public KhachHangVN(int LoaiKH,
     int dinhmuc, int maKH, String hoten, int thangHD, double solg, double dongia, double thanhtien) {
        super(maKH,hoten, thangHD, solg, dongia, thanhtien);
        this.LoaiKH = LoaiKH;
        this.dinhmuc = dinhmuc;
    }
     public int getLoaiKH(){
        return LoaiKH;
     }
     public void setLoaiKH(){
        this.LoaiKH = LoaiKH;

     }
     public void nhap(){
        super.nhap();
       System.out.println("loai khach hang: (1. sinh hoat, 2.kinh doanh, san xuat) ");
       LoaiKH = sc.nextInt() ;
       System.out.println("dinh muc");
        dinhmuc = sc.nextInt();

     }
     
    public double ttien(){
        if (solg <= dinhmuc){
            return this.solg*this.dongia; 
        } else {
            return this.dinhmuc * this.dongia +(this.solg-this.dinhmuc)*this.dongia*2.5 ;}
    }
    @Override
    public String toString(){
        String temp;
   
        if (LoaiKH==1){
            temp="sinh hoaT";
        } else if (LoaiKH==2)
        {
            temp="kinh doanh";
        } else {
            temp="san xuat";
        }
        return "khach hang nuoc ngoai{ " + super.toString() + "loai khach hang" + temp + "dinh muc" + dinhmuc ;
}
}
