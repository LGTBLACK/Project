import java.util.Scanner;

public class QLKH {
    public static void main(String[] args) {
        DSKhachHang dskh = new DSKhachHang();
        Scanner sc = new Scanner(System.in);
        int x;
        do{
        System.out.println("1. them khach hang viet");
        System.out.println("2. them khach nuoc ngoai ");
        System.out.println("3. hien thi them danh sach khach hang");
        System.out.println("4. tong so luong (kw) cua cac khach hang ");
        System.out.println("5. trung binh thanh tien cua khach nuocngoai");
        System.out.println("6. xoa thong tin khach hang");
        System.out.println("7. so luong cua khach hang ");
        x = sc.nextInt();
        switch(x){
                case 1:
                dskh.ThemKH(1);
                break;
                case 2:
                dskh.ThemKH(x);
                break;
                case 3:
                dskh.HienThi();
                break;
                case 4:
                dskh.TOngSL();
                break;
                case 5:
                dskh.trungbinh();
                break;
                case 6:
                dskh.xoaKH(x);
                break;
                case 7: dskh.Slkh();
                break;
                case 8: 
                dskh.ThangHD(x);
                break;

                
                


        }

        

    } while(x!=0);

    }
    

    
    }
