public class KhachHangNN extends KhachHang {
    private String QuocTich;
    
    
    public KhachHangNN(){
        super();
        this.QuocTich = "";

    }
    public KhachHangNN(
        int maKH, String hoten, String QuocTich, int thangHD, double solg, double dongia, double thanhtien){
        super(maKH, hoten, thangHD, solg, dongia, thanhtien);
            this.QuocTich = QuocTich;
        }
        public String getQuocTich(){
            return QuocTich;
        }
        public void setQuocTich() {
            this.QuocTich = QuocTich;
            
        }
    
  
    public void nhap(){
        super.nhap();
        System.out.println("nhap Quoc Tich: ");
        QuocTich = sc.nextLine();
        sc.nextLine();

    }
    public double ttien(){
        return this.solg*this.dongia;
    }
    @Override
    public String toString(){
        
        return "khach hang nuoc ngoai{ " + super.toString() + "QuocTinh=" + QuocTich  ;
    }

}
