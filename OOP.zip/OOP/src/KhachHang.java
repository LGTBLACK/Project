import java.util.Scanner;


public class KhachHang {
    int maKH; String key;
     protected String hoten;
     protected int ThangHD;
     protected double solg;
     protected double dongia, thanhtien;

     Scanner sc = new Scanner(System.in);
    
    
    

    public KhachHang() {
        this.maKH = 0;;
        this.key = "";
        this.hoten = "";
        this.ThangHD = 0;
        this.solg = 0;
        this.dongia = 0;
        this.thanhtien = 0;
    }

    public KhachHang( int maKH, String hoten, int ThangHD, double solg, double dongia, double thanhtien ){
        this.maKH = maKH;
        this.hoten = hoten;
        this.ThangHD = ThangHD;
        this.solg = solg;
        this.dongia = dongia;
        this.thanhtien = thanhtien;
        
    }
    
    public int getmaKH(){
        return maKH;
    }
    public void setmaKH( int maKH){
        this.maKH = maKH;
    }
    public String gethoten(){
        return hoten;
    }
    public void sethoten(String hoten){
         this.hoten = hoten;
    }
    public int getThangHD(){
        return ThangHD;
    }
    public void setThangHD(int ThangHD){
        this.ThangHD = ThangHD;
    }
    public double getsolg(){
        return solg;
    }
    public void setsoLg(double solg){
        this.solg = solg;
    }
    public double getdongia(){
        return dongia;
    }
    public void setdongia(double dongia){
        this.dongia = dongia;
    }
    
    
    
     public void nhap(){
        
        System.out.println("nhap ma khach hang");
        maKH = sc.nextInt();
        System.out.println(" nhap ten khach hang");
        key = sc.nextLine();
        hoten = sc.nextLine();
    
        System.out.println("ngay xuat hoa don");
        ThangHD = sc.nextInt();
        System.out.println("dien nang tieu thu");
        solg = sc.nextDouble();
        System.out.println("gia tien");
        dongia = sc.nextDouble();

    }
    
    @Override
    public String toString(){
        return "maKH" + maKH + "tenKH" + hoten +
         "ngay xuat hoa don" + ThangHD + "so luong" + solg + "don gia" + dongia  ;
    }
}
